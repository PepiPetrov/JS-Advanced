function myFunc(){
    console.log(this);
}

myFunc()