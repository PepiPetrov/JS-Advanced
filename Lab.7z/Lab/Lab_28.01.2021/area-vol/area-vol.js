function solve(area, vol, dataAsJSON) {
const figures=JSON.parse(dataAsJSON)
const result=figures.map(x=>{
    x.x=Math.abs(x.x)
    x.y=Math.abs(x.y)
    x.z=Math.abs(x.z)
    return {area:area.call(x),volume:vol.call(x)}
})
return result
}
const examle=`[
    {"x":"1","y":"2","z":"10"},
    {"x":"7","y":"7","z":"10"},
    {"x":"5","y":"2","z":"10"}
    ]`
function area() {
    return this.x * this.y;
};
function vol() {
    return this.x * this.y * this.z;
};

solve(area,vol,examle)