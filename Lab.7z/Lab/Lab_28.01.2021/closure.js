function createCounter(){
    let counter=0
    function increment(){
        counter++
    }
    function print(){
        console.log(counter)
    }
    return {increment,print}
}


const count=createCounter()
count.print()