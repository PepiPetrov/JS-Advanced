function solution(num){
    function add(n){
        return n+num
    }
    return add
}
const add5=solution(5)
console.log(add5(1));