class Animal{
    constructor(){
        this.kingdom='Animalia'
    }
}
class Mammal extends Animal{
    constructor(){
        super()
        this.class='Mammal'
    }
}
class Dog extends Mammal{
    constructor(){
        super()
        this.type='Dog'
        this.teeth='Big'
    }
}
class GoldenRetreever extends Dog{
    constructor(name,age){
        super()
        this.breed='Golden Retreever'
        this.name=name
        this.age=age
    }
}

const peterRetreever=new GoldenRetreever('Peter')
console.log(peterRetreever.name)