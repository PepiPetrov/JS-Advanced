function Person(name,last,nat){
    this.firstName=name
    this.lastName=last
    this.nationality=nat
}
Person.prototype.write=function(message){
   console.log(`${this.firstName} wrote: ${message}`)
}

const nadya=new Person('Nadya','Petkova','Bulgarian')
nadya.write('Hello World')

console.log((Person.prototype))