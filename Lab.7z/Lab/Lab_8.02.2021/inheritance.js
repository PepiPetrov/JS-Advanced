class Person {
    constructor(name, lastName) {
        this.firstName = name
        this.lastName = lastName
    }
    sayHi(){
        console.log(`${this.firstName} says Hi!`)
    }
}

class Employee extends Person{
    constructor(name,lastName,salary){
        super(name,lastName)
        this.salary=salary
    }
    claim(){
        console.log(`${this.firstName} claimed ${this.salary}$`)
    }
}
const Peter=new Employee('Peter','Petroff',60000)
Peter.sayHi()
Peter.claim()