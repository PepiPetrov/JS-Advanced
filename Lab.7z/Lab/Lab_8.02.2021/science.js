const calc = require('my-libs')
const Calculator = calc.Calculator
const NumericsSystems = calc.NumericSystems
const PhysicsUnits = calc.PhysicsUnits
const Library=calc.Library
let ClassError = new calc.Err('ClassError','Demo')
function demos() {
    let c = new PhysicsUnits().lightSpeed
    function e(m) {
        return (m * c * c) + ' J'
    }
    let hex1234 = new NumericsSystems('1234', 16)
    console.log(hex1234.converted)
    console.log(hex1234.convertBase('1234', 10, 16))
    console.log(Calculator.sum(4, 5))
    console.log(Calculator.subtract(5, 4))
    console.log(Calculator.multiply(5, 4))
    console.log(Calculator.divide(3, 2))
    console.log(Calculator.divide(1, 0))
    console.log(Calculator.pow(2, 3))
    console.log(Calculator.cos(88))
    console.log(Calculator.sin(86))
    console.log(Calculator.tan(942))
    console.log(Calculator.factoriel(5))
    throw new ClassError('Demo')
}
demos()