class Circle{
    constructor(r){
        this.r=r
    }
    get diameter(){
        return this.r*2
    }
    set diameter(value){
        this.r=value/2
    }
}
const circe=new Circle(2)
console.log(circe.r)
circe.diameter=202020202020
console.log(circe.r)