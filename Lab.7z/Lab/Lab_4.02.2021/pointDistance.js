class PointDistance{
    constructor(x,y){
        this.x=x
        this.y=y
    }
    static distance(a,b){
        if(a instanceof PointDistance==false||b instanceof PointDistance==false){
            throw new TypeError(`The parameter must be of type Point!`)
        }
        const d1=(a.x-b.x)**2
        const d2=(a.y-b.y)**2
        return Math.sqrt(d1+d2)
    }
}
const point=new PointDistance(0,1000)
const point2=new PointDistance(4,-30000)
console.log(PointDistance.distance(point,point2))
