function deleteByEmail() {
    const input = document.querySelector('input[name="email"]').value
    const rows = Array.from(document.querySelectorAll('tbody tr'))
    const resultEl = document.getElementById('result')
    const matches = rows.filter(r => r.children[1].textContent == input)
    if (matches.length > 0) {
        matches[0].remove()
        resultEl.textContent = 'Deleted'
    } else {
        resultEl.textContent = 'Not found.'
    }
} 