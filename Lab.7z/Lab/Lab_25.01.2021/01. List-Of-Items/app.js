function addItem() {
    let item=document.getElementById('newItemText').value
    if(item){
    const li=document.createElement('li')
    li.textContent=item
    const ul=document.querySelector('ul')
    ul.appendChild(li)
    document.getElementById('newItemText').value=''
    }
}