const { expect } = require('chai')
const chai = require('chai')
const sum = require('./index')
describe('Tests', () => {
    it('Test #1',()=>{
      expect(sum([1])).to.equal(1)
    }),
    it('Test #2',()=>{
        expect(sum([1,2])).to.equal(3)
    }),
    it('Test #3',()=>{
        expect(sum([1,-2])).to.equal(-1)
    })
})