function subSum(arr,s,e){
    if(typeof(arr)!=='object'){
        throw new TypeError(`${arr} is not an array`)
    }
    if(s<0){
        s=0
    }
    if(e>arr.length-1){
        e=arr.length-1
    }
    let sum=0
    for(let i=s;i<=e;i++){
        if(typeof(arr[i])!=='number'){
            throw new TypeError(`${arr[i]} is not a number`)
        }
       sum+=arr[i]
    }
    console.log(sum)
}
subSum(12,45,22)