const add=require('./index')
const mocha=require('mocha')
describe(it('add 1 and 2 equals 3',function(){
    return add(1,2)==3
}),)