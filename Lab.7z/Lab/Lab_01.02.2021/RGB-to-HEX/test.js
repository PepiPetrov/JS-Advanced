const { expect } = require('chai')
const rgbToHexColor = require('./index')
describe('Suite', () => {
    it('Black', () => {
        expect(rgbToHexColor(0, 0, 0)).to.equal('#000000')
    }),
    it('White', () => {
        expect(rgbToHexColor(255, 255, 255)).to.equal('#FFFFFF')
    }),
    it('Invalid',()=>{
        expect(rgbToHexColor(-1,-1,-1)).to.equal(undefined)
    })
    it('Invalid string params',()=>{
        expect(rgbToHexColor('1a','1a','a1')).to.equal(undefined)
    })
    it('Random color',()=>{
        expect(rgbToHexColor(255,158,170)).to.equal('#FF9EAA')
    })
    it('Out of range',()=>{
        expect(rgbToHexColor(256,435,1234)).to.be.undefined
    })
    it('Pad 0',()=>{
        expect(rgbToHexColor(255,255,25)).to.equal('#0FFFF19')
    })
})