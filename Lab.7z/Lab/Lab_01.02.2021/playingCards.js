function cards(f, s) {
    const suits = {
        'S': '\u2660',
        'H': '\u2665',
        'D': '\u2666',
        'C': '\u2663'
    }
    const faces = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K', 'A']
    return {
       faces,suits:Object.keys(suits),
        toString() {
            if(!faces.includes(f)){
                throw new Error('Invalid face')
            }
            if (!suits.hasOwnProperty(s)) {
                throw new Error('Invalid suit')
            } else {
                console.log(`${f}${suits[s]}`)
            }
        }
    }
}

const card = cards('A', 'S')
card.toString()
const card1=cards('W','S')
//card1.toString()
const card2=cards('1', 'C')
card2.toString()