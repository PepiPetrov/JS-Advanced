function subSum(arr,s,e){
    if(typeof(arr)!=='object'){
        return NaN
    }
    if(s<0){
        s=0
    }
    if(e>arr.length-1){
        e=arr.length-1
    }
    let sum=0
    for(let i=s;i<=e;i++){
        if(typeof(arr[i])!=='number'){
            return NaN
        }
       sum+=arr[i]
    }
    return sum
}
module.exports=subSum