try {
    throw new Error('My error')
} catch (error) {
    console.dir(error.message)
}