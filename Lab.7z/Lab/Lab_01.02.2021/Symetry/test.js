const { expect } = require('chai')
const chai = require('chai')
const symetry = require('./index')
describe('IsSymetric', () => {
    it('Valid input', () => {
        expect(symetry([1, 2, 1])).to.be.true
    }),
    it('Valid input, not symetric',()=>{
        expect(symetry([1,2])).to.be.false
    }),
    it('Invalid type of argument',()=>{
        expect(symetry('a')).to.be.false
    }),
    it('Length of array is odd, expected true',()=>{
     expect(symetry(['a','b','a'])).to.be.true
    }),
    it('Even length, but not equal in the middle',()=>{
        expect(symetry([1,2,3,1])).to.be.false
    }),
    it('coerce',()=>{
        expect(symetry([1,'1'])).to.be.false
    })
})