function day(dayWekk){
    let days={
        'Monday':1,
        'Tuesday':2,
        'Wednesday':3,
        'Thursday':4,
        'Friday':5,
        'Saturday':6,
        'Sunday':7
    }
    if(days.hasOwnProperty(dayWekk)){
        console.log(days[dayWekk])
    }else{
        console.log('error')
    }
}