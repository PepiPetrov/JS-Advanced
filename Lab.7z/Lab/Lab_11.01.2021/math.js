function math(a,b,op){
    [a,b]=[Number(a),Number(b)]
    let operations={
        '+':(a,b)=>a+b,
        '-':(a,b)=>a-b,
        '*':(a,b)=>a*b,
        '/':(a,b)=>a/b,
        '%':(a,b)=>a%b,
        '**':(a,b)=>a**b
    }
    console.log(operations[op](a,b))
}

math(1,2,'**')