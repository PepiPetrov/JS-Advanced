function strLen(s,s1,s2){
    let result=s.length+s2.length+s1.length;
    let averr=result/3
    console.log(result)
    console.log(Math.floor(averr))
}

strLen('1','2','3')