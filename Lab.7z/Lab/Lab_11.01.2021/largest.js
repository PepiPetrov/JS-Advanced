function largest(a,b,c){
    console.log(`The largest number is ${Math.max(a,b,c)}.`)
}
largest(1,2,3)