function echo(str){
    console.log(str.length);
    console.log(str);
}

echo('1234')