function aggregate(arr){
    let sum=0
    let sec=0;
    let repstr=""
    arr.forEach(element => {
         sum+=element
         repstr+=element
         sec+=1/element
    });
    console.log(sum)
    console.log(sec.toFixed(4))
    console.log(repstr)
}

aggregate([1,2,3])