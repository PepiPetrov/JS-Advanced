function sum(a,b){
    [a,b]=[Number(a),Number(b)]
    let result=0
    for(let i=a;i<=b;i++){
        result+=i
    }
    console.log(result)
}
sum(-8,10)