class Mum{
    setName(name){
       this.name=name
    }
}
class Dad extends Mum{
    setAge(age){
        this.age=age
    }
}
const daddy=new Dad()
const mummy=new Mum()
Dad.prototype.isPrograming=false
daddy.setAge(43)
daddy.setName('Plamen')
mummy.setName('Nadya')
console.log(Dad.prototype.age)
