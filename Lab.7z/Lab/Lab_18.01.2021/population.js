function pop(arr){
    let towns={}
    for(let element of arr){
        element=element.split(' <-> ')
        element[1]=Number(element[1])
        if(towns.hasOwnProperty(element[0])){
            towns[element[0]]+=element[1]
        }else{
            towns[element[0]]=element[1]
        }
    }
    for (const ley in towns) {
        console.log(`${ley} : ${towns[ley]}`)
    }
}

pop(['Tortuga <-> 122'])