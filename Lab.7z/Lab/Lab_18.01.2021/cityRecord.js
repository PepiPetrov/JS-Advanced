function townRecord(name,pop,tre){
    let obj={}
    obj.name=name
    obj.population=pop
    obj.treasury=tre
    return obj
}