manna=1000
live=100
monster=100;
mn='Arukar'
let actions={
    castSpell(name,mana,dmg){
        if(manna>mana){
            console.log(`${name} successfuly casted! Now you have ${manna-mana} manna`)
            manna-=mana
            monster-=dmg
            if(monster<=0){
                this.win()
                return
            }
            this.monsterAttack()
        }
    },
    win(){
console.log(`${mn} died! You won!!!!!`)
    },
    lose(){
        console.log(`Sorry! You died! :(`)
    },
    monsterAttack(){
        let dmg=20
        live-=dmg
        console.log(`${mn} attacked you. Now you have ${live} lives.`)
        if(live<=0){
            this.lose()
        }
    }
}
actions.castSpell('Ultra-hyper-mega fireball',800,50)
actions.castSpell('Water',1,40)
actions.castSpell('Earth',2,10)
//Rect
function createRect(width,height){
 const rect={width,height}
 rect.getArea=function(){
     return rect.width*rect.height
 }
 rect.getP=function(){
     return 2*(rect.width+rect.height)
 }
 return rect
}
console.log(createRect(1,2).getArea())
