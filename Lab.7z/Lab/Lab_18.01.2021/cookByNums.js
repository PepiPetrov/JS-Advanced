function cookByNums(num){
  return {
      chop(){
          num/=2
          console.log(num)
      },
      dice(){
          num=Math.sqrt(num)
          console.log(num)
      },
      spice(){
          console.log(++num)
      },
      bake(){
          console.log(num*=3)
      },
      fillet(){
          console.log(num*=0.8)
      }
  }
}

let cook=cookByNums(9)
cook.dice()
cook.spice()
cook.chop()
cook.bake()
cook.fillet()