function a(c){
    console.log(c);
    if(c<0){
        while(c>0){
            c++
            a(c)
        }
        a(c+1)
    }
}

a(-1000)