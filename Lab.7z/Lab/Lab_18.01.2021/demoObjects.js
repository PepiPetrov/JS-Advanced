let person={
    name:"Peter",
    age:10,
    hairColor:'black'
}
person.job='Programmer'
person.languages='JS and C++'
console.log(person);