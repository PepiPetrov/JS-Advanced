function smallTwo(arr){
    console.log(arr.map(Number).sort((a,b)=>a-b).slice(0,2).join(' '))
}

smallTwo([1,2,3,4,5,-1])