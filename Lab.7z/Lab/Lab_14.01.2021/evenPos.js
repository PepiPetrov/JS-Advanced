function evenPos(arr){
    let str=""
    for(let i=0;i<arr.map(Number).length;i++){
        if(i%2==0){
            str+=arr[i]+" ";
        }
    }
    console.log(str.trim())
}
evenPos([20,30,40])