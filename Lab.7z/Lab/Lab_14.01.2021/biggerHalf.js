function bigger(arr){
    return arr.map(Number).sort((a,b)=>a-b).slice(parseInt(arr.length/2))
}

bigger([3, 19, 14, 7, 2, 19, 6]
)