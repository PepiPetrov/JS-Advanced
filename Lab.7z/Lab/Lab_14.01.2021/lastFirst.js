function lastFirst(arr){
    arr=arr.map(Number)
    let result=0
    result+=arr[0]+arr[arr.length-1]
    return result
}