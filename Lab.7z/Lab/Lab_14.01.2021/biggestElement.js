function biggestElement(matrix){
    let max=Number.NEGATIVE_INFINITY
    for(let i=0;i<matrix.length;i++){
        let row=matrix[i]
        for(let j=0;j<row.length;j++){
            if(max<row[j]){
                max=row[j]
            }
        }
    }
    return max
}
console.log(biggestElement([[1,2,3],[4,5,6]]))