function pieceOfPie(arr,sttr1,str2){
    let result=arr.slice(arr.indexOf(sttr1),arr.indexOf(str2)+1)
    return result
}

pieceOfPie([1,2,3,4],1,3)