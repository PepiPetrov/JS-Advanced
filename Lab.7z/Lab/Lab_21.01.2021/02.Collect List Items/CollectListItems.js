function extractText() {
    const liS=Array.from(document.querySelectorAll('li')).map(x=>x=x.textContent)
    document.getElementById('result').value=liS.join('\n')  
}