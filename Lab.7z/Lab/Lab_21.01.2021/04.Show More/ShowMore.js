function showText() {
document.getElementById('text').style.display = 'inline';
document.getElementById('more').style.display = 'none';
}