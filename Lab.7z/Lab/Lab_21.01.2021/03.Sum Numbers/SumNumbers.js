function calc() {
    const num1=Number(document.getElementById('num1').value)
    const num2=Number(document.getElementById('num2').value)
    document.getElementById('sum').value=String(num2+num1)
}
