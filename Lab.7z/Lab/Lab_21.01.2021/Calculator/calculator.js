function calc() {
    let num1 = document.getElementById('num1').value;
    let num2 = document.getElementById('num2').value;
    let op = document.getElementById('choose').value
    let sum;
    switch(op){
        case '+':sum=num1+num2;break
        case '-':sum=num1-num2;break
        case '*':sum=num1*num2;break
        case '/':sum=(num1/num2).toFixed(2);break
        case '^':sum=num1**num2;break
    }
    document.getElementById('sum').value = Number(sum);
}